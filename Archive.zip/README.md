# Quack Search
## quacksearch.github.io
Quack search, The open-source search engine powered by quack api.

### Info:
Quack engine, an open-source search engine project based on quack search engine api. How it's defferent with other search engines all around the world? Basically quack engine is a engine that provides exact resualts anyone can get in to one place. 
<br>

https://quacksearch.github.io

# Technologies with quack engine
<br>
<img src="assets/img/technologies/Bootstrap_logo.png" height="50px"></img>
