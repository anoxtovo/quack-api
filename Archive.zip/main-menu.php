<div class="header-menu-main">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="team.php">Our Team</a></li>
    </ul>
</div>