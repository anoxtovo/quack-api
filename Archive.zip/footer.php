<div class="jumbotron text-center blockquote-footer footer-section">
    
    <div class="copyright text-center">
                <p>2022 &copy; Quack Project, Design by<br><a href="team.php">Quack Project team</a></p>
    </div>

    <div id="project-links">
        <a href="https://github.com/anoxtovo/quackengine" target="_blank"><i class="fa-brands fa-github fa-2xl"></i></a>
        <a href="#"><i class="fa-solid fa-book fa-2xl"></i></a>
    </div>

</div>