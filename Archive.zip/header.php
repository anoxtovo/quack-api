<div class="jumbotron text-center site-logo">
    <a href="/"><img src="/assets/img/quack-white.png" alt="Quack Engine"></a>
    <!-- <h1>Quack Engine</h1>
    <p>open source, secure and future engine</p> -->
</div>